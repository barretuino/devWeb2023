package aula.br.edu.uniararas.projetotelefone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnChamar = (Button)findViewById(R.id.btnChamar);
        Button btnTelefone = (Button) findViewById(R.id.btnTelefone);

        btnChamar.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Representa o endereço que será submetido ao navegador
                Uri uri = Uri.parse("http://www.uniararas.br");
                //Criação da Intent
                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                //Enviar a mensagem ao Sistema Operacional
                //informando o direcionamento de uma 'Intent'
                iniciarIntent(it);
            }
        });

        btnTelefone.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                //Representa o número de telefone que desejo discar
                Uri uri = Uri.parse("34621026");
                //Criação da Intent
                Intent it = new Intent(Intent.ACTION_CALL, uri);
                //Enviar uma mensagem ao Sistema Operacional
                //informando a minha 'Intent' de ação
                iniciarIntent(it);
            }
        });
    }

    public void iniciarIntent(Intent it){
        startActivity(it);
        finish();
    }

    //Criar o Menu da Aplicação
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.acaoTelefonar){
            Log.i("Saída do Menu", "Você escolheu: " + id);
        }
        return super.onOptionsItemSelected(item);
    }
}