# Recebendo dados JSON

Nesse exemplo eu carrego dados do site https://jsonplaceholder.typicode.com/users, foi criado também a página de detalhes

![image](images/tela1.png)

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
