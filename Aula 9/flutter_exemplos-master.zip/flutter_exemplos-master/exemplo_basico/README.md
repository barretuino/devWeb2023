# Exemplo Flutter Basico

Configuração de projeto inicial

![image](images/exemplo.png)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
