# Exemplo de Splash Flutter

Nesse exemplo adicionei uma tela Splash que seja para a tela principal do app

<img src="https://raw.githubusercontent.com/programadornatal/flutter_exemplos/master/splash_flutter/images/splashexemplo.gif" width="350px" alt="image" style="width: 350px;">

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
