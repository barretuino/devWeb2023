import 'package:flutter/material.dart';

class fragmentoTwo extends StatefulWidget {
  @override
  _fragmentoTwoState createState() => _fragmentoTwoState();
}

class _fragmentoTwoState extends State<fragmentoTwo> {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: new Center(
          child: new Text("Fragmento 2"),
        )
    );
  }
}
