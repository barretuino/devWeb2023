# Exemplo de Flutter com Redux

![Image](images/tela.png)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
