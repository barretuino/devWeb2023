import 'package:flutter/material.dart';

class fragmentoTree extends StatefulWidget {
  @override
  _fragmentoTreeState createState() => _fragmentoTreeState();
}

class _fragmentoTreeState extends State<fragmentoTree> {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: new Center(
          child: new Text("Fragmento 3"),
        )
    );
  }
}
