# Unicornio exemplo

Foi utilizado a lib: 
```
unicorndial: "^1.1.4"
```

![Image](images/tela.gif)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
