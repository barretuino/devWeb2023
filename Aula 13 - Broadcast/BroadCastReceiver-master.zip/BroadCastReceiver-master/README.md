BroadCastReceiver examples
=================
eclipse/ is the examples for use in eclipse. This is no longer updated. The rest of the examples are in Android studio format.

<B>BroadCastDemo1</b>: Simple implementation of a receiver with a static and dynamic registered intent-filter

<B>BroadCastDemo2</b>: Setup to receive intents about battery status and power status.
Also uses android:launchMode="singleTop" so that only one activity is launched, when it is the foreground app.

<B>BroadcastNoti</b>: A reimplementation of the notification demo, but using only receivers for the broadcast.

<B>BroadcastBoot</b>: Receives a broadcast on boot, that starts a service.



These are example code for University of Wyoming, Cosc 4730 Mobile Programming course.  The examples are for Android.