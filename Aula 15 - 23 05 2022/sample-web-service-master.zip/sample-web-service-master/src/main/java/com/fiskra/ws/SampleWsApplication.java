package com.fiskra.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleWsApplication.class, args);
	}
}
