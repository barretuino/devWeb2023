package com.fiskra.ws.model;

import org.springframework.hateoas.ResourceSupport;

public class BookmarkResource extends ResourceSupport{
	
	public Bookmark bookmark;

}
