
INSERT INTO User (email,name) VALUES ('fferide.celik@gmail.com', 'Feride');
INSERT INTO User (email,name) VALUES ('admin.admin@gmail.com', 'admin');

insert into Bookmark (uri, description, user_id) values ('//http://bookmark.com/1/', 'a first description', 1);
insert into Bookmark (uri, description, user_id) values ('//http://bookmark.com/2/', 'a second description', 1);
insert into Bookmark (uri, description, user_id) values ('//http://bookmark.com/44/', 'a third description', 2);