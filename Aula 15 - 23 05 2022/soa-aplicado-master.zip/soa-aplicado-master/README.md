# soa-aplicado
Códigos fontes dos estudos sobre SOA do Livro "SOA Aplicado" da Casa do Código.
